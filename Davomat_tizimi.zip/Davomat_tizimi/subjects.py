from database import create_connection

def add_subject(subject_name):
    # Yangi fan qo'shish
    conn = create_connection()
    conn.execute('INSERT INTO subjects (name) VALUES (?)', (subject_name,))
    conn.commit()
    conn.close()

def get_all_subjects():
    # Barcha fanlarni olish
    conn = create_connection()
    subjects = conn.execute('SELECT * FROM subjects').fetchall()
    conn.close()
    return subjects

def delete_subject(subject_id):
    # Fanni o'chirish
    conn = create_connection()
    conn.execute('DELETE FROM subjects WHERE id = ?', (subject_id,))
    conn.commit()
    conn.close()
