from flask import Flask, render_template, request, redirect, url_for, session, flash
from database import create_connection, create_tables, get_user_by_username, add_log
import hashlib
from subjects import add_subject, get_all_subjects, delete_subject
from functools import wraps
from flask import abort
from functools import wraps
from flask import abort

app = Flask(__name__)
app.secret_key = 'judaxavfsiz_kalit'  # Buni real loyihada maxfiy saqlang
create_tables()



def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

@app.route('/admin/add_teacher', methods=['GET', 'POST'])
def add_teacher():
    # faqat adminlarga ruxsat beramiz
    if session.get('role') != 'admin':
        flash('Sizda ushbu sahifaga kirish uchun ruxsat yo‘q.', 'danger')
        return redirect(url_for('index'))
    
    conn = create_connection()
    cursor = conn.cursor()
    
    # fanlar ro'yxatini olish
    cursor.execute("SELECT id, subject_name FROM subjects")
    subjects = cursor.fetchall()

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        full_name = request.form['full_name']
        selected_subjects = request.form.getlist('subjects')  # ko'p fan bo'lishi mumkin
        
        # parolni hash qilish
        password_hash = hash_password(password)

        # yangi o'qituvchi qo'shish
        try:
            cursor.execute(
                "INSERT INTO users (username, password_hash, role, full_name) VALUES (?, ?, 'teacher', ?)",
                (username, password_hash, full_name)
            )
            teacher_id = cursor.lastrowid
            
            # fanlarni bog'lash
            for subj_id in selected_subjects:
                cursor.execute(
                    "INSERT INTO teacher_subjects (teacher_id, subject_id) VALUES (?, ?)",
                    (teacher_id, subj_id)
                )
            
            conn.commit()
            flash('Yangi o‘qituvchi muvaffaqiyatli qo‘shildi.', 'success')
            return redirect(url_for('add_teacher'))
        except Exception as e:
            conn.rollback()
            flash(f'Xatolik yuz berdi: {str(e)}', 'danger')
    
    return render_template('add_teacher.html', subjects=subjects)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'role' not in session or session['role'] != 'admin':
            flash('Sizda admin huquqlari yo‘q!', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/admin')
@admin_required
def admin_panel():
    # Bu yerda admin uchun maxsus ma'lumotlarni ko'rsatamiz
    return render_template('admin_panel.html')

# Asosiy sahifa: Talabalar ro'yxati
@app.route('/')
def index():
    if not session.get('user_id'):
        return redirect(url_for('login'))
    # Aks holda asosiy sahifani ko‘rsatish
    conn = create_connection()
    # Ism bo‘yicha tartiblab olish
    students = conn.execute('SELECT * FROM students ORDER BY name ASC').fetchall()
    conn.close()
    subjects = get_all_subjects()  # Fanlar ro'yxatini olish
    return render_template('index.html', students=students, subjects=subjects)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = get_user_by_username(username)
        
        if user:
            password_hash = hashlib.sha256(password.encode()).hexdigest()
            if password_hash == user['password_hash']:
                session['user_id'] = user['id']
                session['username'] = user['username']
                session['role'] = user['role']
                flash('Muvaffaqiyatli tizimga kirdingiz!', 'success')
                add_log(user['id'], 'login', f"{username} tizimga kirdi")
                return redirect(url_for('index'))
            else:
                flash('Parol noto‘g‘ri', 'danger')
        else:
            flash('Foydalanuvchi topilmadi', 'danger')

    return render_template('login.html')

@app.route('/logout')
def logout():
    user_id = session.get('user_id')
    if user_id:
        add_log(user_id, 'logout', f"{session.get('username')} tizimdan chiqdi")
    session.clear()
    flash('Tizimdan chiqdingiz', 'info')
    return redirect(url_for('login'))

# Talaba qo'shish sahifasi
@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = request.form['name']
        student_id = request.form['student_id']
        conn = create_connection()
        conn.execute('INSERT INTO students (name, student_id) VALUES (?, ?)', (name, student_id))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('add_student.html')

@app.route('/report', methods=['GET', 'POST'])
def report():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = create_connection()
    cursor = conn.cursor()

    # Barcha fanlar ro'yxatini olish
    cursor.execute("SELECT * FROM subjects")
    subjects = cursor.fetchall()

    selected_subject_id = None

    if request.method == 'POST':
        selected_subject_id = request.form.get('subject_id')

        if selected_subject_id:
            cursor.execute('''
                SELECT attendance.id, students.name, subjects.name as subject_name, attendance.date, attendance.status
                FROM attendance
                JOIN students ON attendance.student_id = students.student_id
                LEFT JOIN subjects ON attendance.subject_id = subjects.id
                WHERE subjects.id = ?
                ORDER BY attendance.date DESC
            ''', (selected_subject_id,))
        else:
            cursor.execute('''
                SELECT attendance.id, students.name, subjects.name as subject_name, attendance.date, attendance.status
                FROM attendance
                JOIN students ON attendance.student_id = students.student_id
                LEFT JOIN subjects ON attendance.subject_id = subjects.id
                ORDER BY attendance.date DESC
            ''')
    else:
        cursor.execute('''
            SELECT attendance.id, students.name, subjects.name as subject_name, attendance.date, attendance.status
            FROM attendance
            JOIN students ON attendance.student_id = students.student_id
            LEFT JOIN subjects ON attendance.subject_id = subjects.id
            ORDER BY attendance.date DESC
        ''')

    records = cursor.fetchall()
    conn.close()

    return render_template('report.html', records=records, subjects=subjects, selected_subject_id=selected_subject_id)


# Davomat belgilash sahifasi
@app.route('/mark_attendance', methods=['GET', 'POST'])
def mark_attendance():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = create_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        subject_id = request.form['subject']
        date = request.form['date']
        
        students = cursor.execute('SELECT * FROM students').fetchall()
        
        for student in students:
            status = request.form.get(f'attendance_{student["id"]}')
            if status:
                cursor.execute('''
                    INSERT INTO attendance (student_id, subject_id, date, status)
                    VALUES (?, ?, ?, ?)
                ''', (student['student_id'], subject_id, date, status))
        
        conn.commit()
        conn.close()
        return redirect(url_for('index'))

    subjects = cursor.execute('SELECT * FROM subjects').fetchall()
    students = cursor.execute('SELECT * FROM students').fetchall()
    
    conn.close()
    
    return render_template('mark_attendance.html', subjects=subjects, students=students)

# Fanlar boshqaruvi sahifasi
@app.route('/manage_subjects', methods=['GET', 'POST'])
def manage_subjects():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = create_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        subject_name = request.form['subject_name']
        cursor.execute('INSERT INTO subjects (name) VALUES (?)', (subject_name,))
        conn.commit()

    # Fanlar ro'yxatini olish
    cursor.execute('SELECT * FROM subjects')
    subjects = cursor.fetchall()
    conn.close()

    return render_template('manage_subjects.html', subjects=subjects)


# Fanni o'chirish
@app.route('/delete_subject/<int:subject_id>', methods=['GET'])
def delete_subject_route(subject_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    delete_subject(subject_id)  # Fanni o'chirish
    return redirect(url_for('manage_subjects'))  # O'chirilgandan so'ng, qayta manage_subjects sahifasiga o'tish

if __name__ == '__main__':
    app.run(debug=True)
