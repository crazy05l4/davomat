import hashlib
from database import create_connection

def create_admin_user():
    conn = create_connection()
    cursor = conn.cursor()

    username = 'admin'
    password = 'admin123'  # Kuchliroq parol tavsiya qilinadi
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    role = 'admin'
    full_name = 'Admin User'

    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    if cursor.fetchone():
        print("Admin foydalanuvchi allaqachon mavjud.")
    else:
        cursor.execute(
            'INSERT INTO users (username, password_hash, role, full_name) VALUES (?, ?, ?, ?)',
            (username, password_hash, role, full_name)
        )
        conn.commit()
        print("Admin foydalanuvchi yaratildi.")

    conn.close()

if __name__ == '__main__':
    create_admin_user()
